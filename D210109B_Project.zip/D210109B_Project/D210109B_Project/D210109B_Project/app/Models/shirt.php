<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class shirt extends Model
{
    use HasFactory;
    protected $fillable=['name','price','image','quantity','brandID'];

    public function myCart(){
        return $this->hasMany('App\Models\Mycart');
    }

    public function brandCategory(){
        return $this->belongsTo('App\Models\brandCategory');
    }
}
