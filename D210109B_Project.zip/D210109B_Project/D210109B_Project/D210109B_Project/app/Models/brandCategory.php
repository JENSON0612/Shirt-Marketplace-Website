<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class brandCategory extends Model
{
    use HasFactory;
    protected $fillable=['name'];

    public function shirt(){
        return $this->hasMany('App\Models\shirt');
    }
}
