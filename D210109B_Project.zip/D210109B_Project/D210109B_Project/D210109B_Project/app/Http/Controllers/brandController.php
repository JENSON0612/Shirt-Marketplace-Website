<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\brandCategory;
use App\Models\shirt;

class brandController extends Controller
{
    public function add(){
        $r=request();
        $uploadBrand=brandCategory::create([
            'name'=>$r->brandName,
        ]);
        return view('uploadBrand');
    }
    
}
