<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\shirt;
use DB;

class barcodeController extends Controller
{

    public function print(){
        return view('barcodeDisplay');
    }

    public function generateBarcode(){
        return view('barcodeDisplay');
}



}