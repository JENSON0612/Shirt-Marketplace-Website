<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\shirt;
use App\Models\brandCategory;

class shirtController extends Controller
{
    public function home(){
        return view('welcome');
    }

    public function shirt(){
        return view('shirt');
    }

    public function contactUs(){
        return view('barcodeDisplay');
    }

    public function uploadShirt(){
        return view('uploadShirt');
    }

    public function uploadBrand(){
        return view('uploadBrand');
    }





    public function add(){
        $r=request();
        if($r->file('imageName')!=''){
            $imageName=$r->file('imageName');
            $imageName->move('images',$imageName->getClientOriginalName());
            $imageName=$imageName->getClientOriginalName();
        }
        else{
            $imageName="null.jpg";
        }

        $r=request();
        $addShirt=shirt::create([
            'name'=>$r->shirtName,
            'image'=>$imageName,
            'brandID'=>$r->brandID,
        ]);

        return view('uploadShirt');
    }

    public function show(){
        $viewAll = shirt::all();
        return view('shirt')->with('shirts', $viewAll);
    }

    public function showDetails($id){
        $viewAll = shirt::all()->where('id', $id);
        //SQL select * form shirt where id='$id'
        return view('shirtDetails')->with('shirts', $viewAll);
    }
       
}
