
<?php $__env->startSection('content'); ?>
<form method="get" action="<?php echo e(route('barcodeDisplay')); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" name="id" id="id"/>
    <input type="submit" name="Generate Barcode" class= "btn btn-warning bg-dark" style="color:#ffc107;"/>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SCHOOL\web\D210109B_Project\D210109B_Project\resources\views/barcode.blade.php ENDPATH**/ ?>