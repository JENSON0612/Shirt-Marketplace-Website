
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-2">&nbsp;</div>
    <div class="col-sm-8">
        <form action="<?php echo e(route('uploadBrand')); ?>" method="post"><br><br><?php echo csrf_field(); ?>
        <h3>Brand Name :</h3> <input name="brandName" type="text" class="form-control"><br>
        <button type="submit" style="color:#ffc107;" class="btn btn-warning bg-dark">Add Brand</button><br><br>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SCHOOL\web\D210109B_Project\D210109B_Project\resources\views/uploadBrand.blade.php ENDPATH**/ ?>