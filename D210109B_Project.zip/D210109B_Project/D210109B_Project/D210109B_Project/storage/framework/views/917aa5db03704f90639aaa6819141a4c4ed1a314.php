
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-2">&nbsp;</div>
    <div class="col-sm-8">
        <form action="<?php echo e(route('uploadShirt')); ?>" method="post" enctype="multipart/form-data"><br><br> <?php echo csrf_field(); ?>
            <h3>Add New Shirt</h3>
            Shirt: <input name="shirtName" type="text" class="form-control"><br>
            Image: <input name="imageName" type="file" class="form-control"><br>
            Brand: 
            <select name="brandID" id="" class="form-control">
             <option value="">Select Brand</option>
             <option value="1">ADLV</option>
             <option value="2">STUSSY</option>
             <option value="3">RICKY IS CLOWN</option>
            </select><br>
            <button type="submit" style="color:#ffc107;" class="btn btn-warning bg-dark">Add Shirt</button><br><br>
        </form>
    </div>
    <div class="col-sm-2">&nbsp;</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SCHOOL\web\D210109B_Project\D210109B_Project\resources\views/uploadShirt.blade.php ENDPATH**/ ?>