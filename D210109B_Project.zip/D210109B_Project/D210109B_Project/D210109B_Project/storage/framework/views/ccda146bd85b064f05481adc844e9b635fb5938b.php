
<?php $__env->startSection('content'); ?>
<div class="row">
    <?php $__currentLoopData = $stussys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stussy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-4">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($stussy->name); ?></h5>
            <a href="">
                <img src="<?php echo e(asset('images')); ?>/<?php echo e($stussy->image); ?>" alt="" class="img-fluid">
            </a>
            <div class="card-heading">RM <?php echo e($stussy->price); ?></div>
            <button class="btn btn-warning bg-dark" style="color:#ffc107;">Add To Cart</button>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SCHOOL\web\D210109B_Project\D210109B_Project\resources\views/stussy.blade.php ENDPATH**/ ?>