<?php echo DNS1D::getBarcodeSVG($barcode->brandID, "C39", 1, 25, '#2A3239'); ?>

<br><br><br>
<br>
<?php echo e(barcode->brandID); ?><?php /**PATH F:\SCHOOL\web\D210109B_Project\D210109B_Project\resources\views/barcodeshow.blade.php ENDPATH**/ ?>