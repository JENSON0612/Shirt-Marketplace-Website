<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laravel Generate Barcode Examples</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
</head>
<body>
    <br><br><br><br><br><br><br><br><br><br><br><br>
    <div class = "container mt-4" align="center">
    <div class="mb-3"><?php echo DNS1D::getBarcodeHTML('01111484047', 'UPCA'); ?></div> 
    <h3 class="text-center">JS FASHION NUMBER </h3> 

   
        
    </div>
</body>
</html> <?php /**PATH F:\SCHOOL\web\D210109B_Project\D210109B_Project\D210109B_Project\resources\views/barcodeDisplay.blade.php ENDPATH**/ ?>