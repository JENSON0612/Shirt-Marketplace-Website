
<?php $__env->startSection('content'); ?>
    <div class = "row">
        <?php $__currentLoopData = $shirts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shirt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-2"></div>
        <div class = "col-sm-10">
            <div class="card-body">

            <form action="<?php echo e(route('barcodeDisplay')); ?>" method="post">
                <?php echo csrf_field(); ?> 
                <input type="hidden" name="id" value="<?php echo e($shirt->id); ?>">
            

            <div class="row">
                <div class="col-md-3">
                <h5  class = "card-title"><?php echo e($shirt->name); ?></h5>
                <img src="<?php echo e(asset('images')); ?>/<?php echo e($shirt->image); ?>" alt="" class ="img-fluid" value="$shirt->image"><br><br><br><br><br><br><br>
                </div>

                <div class="col-md-9"><br><br>
            <br><br>
            <br>
            <h3>Call us to know more about our clothes!</h3>
            <p>By pressing the button below</p>
            <a href="<?php echo e(route('shirtDetails', ['id' => $shirt ->id] )); ?>"></a>
            <button style="color:#ffc107;" class="btn btn-warning bg-dark" type="submit" >Print</button>
        </div>
        </form>

        </div>

            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SCHOOL\web\D210109B_Project\D210109B_Project\D210109B_Project\resources\views/shirtDetails.blade.php ENDPATH**/ ?>