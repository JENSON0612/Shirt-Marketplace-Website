<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\barcodeController;
use App\Http\Controllers\shirtController;
use App\Http\Controllers\brandController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/uploadShirt', function () {
    return view('uploadShirt');
});

Route::get('/uploadBrand', function () {
    return view('uploadBrand');
});

Route::get('/welcome',[App\Http\Controllers\shirtController::class, 'home'])->name('welcome');

Route::get('/shirt',[App\Http\Controllers\shirtController::class, 'shirt'])->name('shirt');

Route::get('/uploadShirt',[App\Http\Controllers\shirtController::class, 'uploadShirt'])->name('uploadShirt');

Route::get('/uploadBrand',[App\Http\Controllers\shirtController::class, 'uploadBrand'])->name('uploadBrand');

Route::get('/barcodeDisplay',[App\Http\Controllers\shirtController::class, 'contactUs'])->name('barcodeDisplay');

Route::post('/uploadShirt/store', [App\Http\Controllers\shirtController::class, 'add'])->name('uploadShirt');

Route::post('/uploadBrand/store', [App\Http\Controllers\brandController::class, 'add'])->name('uploadBrand');

Route::get('/shirt',[App\Http\Controllers\shirtController::class, 'show'])->name('shirt');

Route::get('/shirtDetails/{id}',[App\Http\Controllers\shirtController::class,'showDetails'])->name('shirtDetails');

Route::post('/barcode', [barcodeController::class, 'print'])->name('barcodeDisplay');

Route::get('/barcode', [barcodeController::class, 'generateBarcode'])->name('barcodeDisplay');


