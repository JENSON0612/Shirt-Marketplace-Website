@extends('layout')
@section('content')
<div class="row">
    <div class="col-sm-2">&nbsp;</div>
    <div class="col-sm-8" align="center">
        <form action="{{route('uploadBrand')}}" method="post"><br><br>@csrf<br><br><br><br><br>
        <h3>Brand Name :</h3> <input name="brandName" align="center" type="text" class="form-control"><br>
        <button type="submit" style="color:#ffc107;" class="btn btn-warning bg-dark">Add Brand</button><br><br><br><br><br><br><br><br>
        </form>
    </div>
</div>
@endsection