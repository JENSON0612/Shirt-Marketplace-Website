@extends('layout')
@section('content')
    <div class = "row">
        @foreach($shirts as $shirt)
        <div class = "col-sm-4">
            <div class = "card-body">
                <h5 class = "card-title">{{$shirt->name}}</h5>
                <img src="{{asset('images')}}/{{$shirt->image}}" alt="" class = "img-fluid"></a>
                <a href="{{route('shirtDetails', ['id' => $shirt ->id])}}"><br><br>
                <button class = "btn btn-warning bg-dark" style="color:#ffc107;">View</button></a>
            </div>
        </div>
        @endforeach
    </div>

@endsection