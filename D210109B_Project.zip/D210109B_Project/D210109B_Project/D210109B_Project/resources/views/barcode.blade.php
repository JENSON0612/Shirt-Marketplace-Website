@extends('layout')
@section('content')
<form method="get" action="{{route('barcodeDisplay')}}">
    @csrf
    <input type="text" name="id" id="id"/>
    <input type="submit" name="Generate Barcode" class= "btn btn-warning bg-dark" style="color:#ffc107;"/>
</form>
@endsection