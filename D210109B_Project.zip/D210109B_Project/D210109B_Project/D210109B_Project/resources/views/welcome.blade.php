@extends('layout')
@section('content')
<div class="col-sm-12">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner" >
            <div class="carousel-item active">
              <img src="https://media.karousell.com/media/photos/products/2022/8/17/original_ricky_is_clown_shirt__1660725318_73c85b8d_progressive.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="https://www.buyandship.com.sg/contents/uploads/2021/10/stussy_web2.jpeg"  class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="https://kpopping.com/documents/4e/5/800/EZ5V1MsUwAEOw3q.jpeg?v=daf87" class="d-block w-100" alt="...">
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-target="#carouselExampleIndicators" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </button><br>
          <button class="carousel-control-next" type="button" data-target="#carouselExampleIndicators" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </button>
        </div>

       </div>

@endsection 