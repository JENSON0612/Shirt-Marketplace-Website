@extends('layout')
@section('content')
<div class="row">
    <div class="col-sm-2">&nbsp;</div>
    <div class="col-sm-8">
        <form action="{{route('uploadShirt')}}" method="post" enctype="multipart/form-data"><br><br> @csrf
            <h3>Add New Shirt</h3>
            Shirt: <input name="shirtName" type="text" class="form-control"><br>
            Image: <input name="imageName" type="file" class="form-control"><br>
            Brand: 
            <select name="brandID" id="" class="form-control">
             <option value="">Select Brand</option>
             <option value="1">ADLV</option>
             <option value="2">STUSSY</option>
             <option value="3">RICKY IS CLOWN</option>
            </select><br>
            <button type="submit" style="color:#ffc107;" class="btn btn-warning bg-dark">Add Shirt</button><br><br><br><br><br>
        </form>
    </div>
    <div class="col-sm-2">&nbsp;</div>
</div>
@endsection