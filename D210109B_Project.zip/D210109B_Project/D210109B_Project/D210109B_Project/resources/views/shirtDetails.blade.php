@extends('layout')
@section('content')
    <div class = "row">
        @foreach($shirts as $shirt)
        <div class="col-sm-2"></div>
        <div class = "col-sm-10">
            <div class="card-body">

            <form action="{{route('barcodeDisplay')}}" method="post">
                @csrf 
                <input type="hidden" name="id" value="{{$shirt->id}}">
            

            <div class="row">
                <div class="col-md-3">
                <h5  class = "card-title">{{$shirt->name}}</h5>
                <img src="{{asset('images')}}/{{$shirt->image}}" alt="" class ="img-fluid" value="$shirt->image"><br><br><br><br><br><br><br>
                </div>

                <div class="col-md-9"><br><br>
            <br><br>
            <br>
            <h3>Call us to know more about our clothes!</h3>
            <p>By pressing the button below</p>
            <a href="{{route('shirtDetails', ['id' => $shirt ->id] )}}"></a>
            <button style="color:#ffc107;" class="btn btn-warning bg-dark" type="submit" >Print</button>
        </div>
        </form>

        </div>

            </div>

        </div>
        @endforeach
    </div>

@endsection